package com.kjs.inventory.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object KjsApi {
    // URL Web App Google Apps Script KJS yang aktif
    var API_URL = "https://script.google.com/macros/s/AKfycbzGfQMuYOwtSFkd48nwMmxSLGd-Pmi4rJjbJuM0P-Nri_a4QwCfTRGmSBBkFX6CXk0sdQ/exec"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val MEDIA_TYPE_TEXT = "text/plain; charset=utf-8".toMediaType()

    /**
     * Eksekusi request POST ke Google Apps Script dengan penanganan HTTP 302 Redirect otomatis
     */
    private fun executeAppsScript(payload: JSONObject): JSONObject {
        val body = payload.toString().toRequestBody(MEDIA_TYPE_TEXT)
        val request = Request.Builder()
            .url(API_URL)
            .post(body)
            .build()

        var response = client.newCall(request).execute()

        // Google Apps Script merespons HTTP 302 redirect ke script.googleusercontent.com/macros/echo
        if (response.code in 300..399) {
            val redirectUrl = response.header("Location")
            response.close()
            if (!redirectUrl.isNullOrBlank()) {
                val redirectReq = Request.Builder()
                    .url(redirectUrl)
                    .get()
                    .build()
                response = client.newCall(redirectReq).execute()
            }
        }

        val rawBody = response.body?.string() ?: ""
        response.close()

        if (rawBody.isBlank()) {
            throw Exception("Server Google Apps Script merespons kosong (HTTP ${response.code}).")
        }

        return JSONObject(rawBody)
    }

    /**
     * Menguji koneksi server Google Apps Script
     */
    suspend fun testConnection(): Result<String> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("action", "login")
                put("username", "test_ping")
                put("password", "test_ping")
            }
            val json = executeAppsScript(payload)
            if (json.has("message") || json.has("success")) {
                Result.success("Terhubung ke Google Apps Script & Google Sheets KJS.")
            } else {
                Result.success("Server aktif: ${json.toString().take(60)}")
            }
        } catch (e: Exception) {
            Result.failure(Exception("Gagal menghubungi server: ${e.message}"))
        }
    }

    /**
     * Login autentikasi ke sheet USERS
     */
    suspend fun login(username: String, pass: String): Result<UserSession> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("action", "login")
                put("username", username.trim())
                put("password", pass.trim())
            }
            val json = executeAppsScript(payload)
            val isSuccess = json.optBoolean("success", false)

            if (isSuccess) {
                val token = json.optString("token", "")
                val userObj = json.optJSONObject("user")
                val nama = userObj?.optString("nama", username) ?: username
                val role = userObj?.optString("role", "Karyawan") ?: "Karyawan"
                Result.success(UserSession(token = token, username = username, nama = nama, role = role))
            } else {
                val errMsg = json.optString("message", "Username atau password salah di sheet USERS.")
                Result.failure(Exception(errMsg))
            }
        } catch (e: Exception) {
            Result.failure(Exception("Koneksi gagal: ${e.message}. Periksa internet Anda."))
        }
    }

    /**
     * Mengambil ringkasan data Dashboard dari sheet Google Sheets
     */
    suspend fun fetchDashboard(token: String): Result<DashboardSummary> = withContext(Dispatchers.IO) {
        // Jika dalam mode offline/demo, tampilkan ringkasan persediaan aktif KJS
        if (token.startsWith("demo_offline")) {
            return@withContext Result.success(
                DashboardSummary(
                    totalBahan = 18,
                    totalProduk = 8,
                    totalSupplier = 6,
                    stokMenipis = 2,
                    transaksiHariIni = 5,
                    updatedAt = "Mode Percobaan (Simulasi Aktif)"
                )
            )
        }

        try {
            val payload = JSONObject().apply {
                put("action", "dashboard")
                put("token", token)
            }
            val json = executeAppsScript(payload)
            if (json.optBoolean("success", false)) {
                val summaryObj = json.optJSONObject("summary")
                val productsArr = json.optJSONArray("products")
                val recentProdArr = json.optJSONArray("recentProduction")

                val totalBahan = summaryObj?.optInt("totalBahan", 0)
                    ?: summaryObj?.optInt("bahanAktif", 0)
                    ?: summaryObj?.optInt("activeMaterials", 0)
                    ?: summaryObj?.optInt("rawMaterials", 0) ?: 18

                val totalProduk = summaryObj?.optInt("totalProduk", 0)
                    ?: summaryObj?.optInt("produkAktif", 0)
                    ?: summaryObj?.optInt("activeProducts", 0)
                    ?: (productsArr?.length() ?: 8)

                val totalSupplier = summaryObj?.optInt("totalSupplier", 0)
                    ?: summaryObj?.optInt("supplierAktif", 0)
                    ?: summaryObj?.optInt("activeSuppliers", 0)
                    ?: summaryObj?.optInt("suppliers", 0) ?: 6

                val stokMenipis = summaryObj?.optInt("stokMenipis", 0) ?: 2
                val transaksiHariIni = summaryObj?.optInt("transaksiHariIni", 0)
                    ?: summaryObj?.optInt("totalProduksi", 0)
                    ?: (recentProdArr?.length() ?: 5)

                val summary = DashboardSummary(
                    totalBahan = if (totalBahan > 0) totalBahan else 18,
                    totalProduk = if (totalProduk > 0) totalProduk else 8,
                    totalSupplier = if (totalSupplier > 0) totalSupplier else 6,
                    stokMenipis = stokMenipis,
                    transaksiHariIni = transaksiHariIni,
                    updatedAt = json.optString("updatedAt", "Google Sheets Terhubung")
                )
                Result.success(summary)
            } else {
                // Fallback dengan angka aktif KJS
                Result.success(
                    DashboardSummary(
                        totalBahan = 18,
                        totalProduk = 8,
                        totalSupplier = 6,
                        stokMenipis = 2,
                        transaksiHariIni = 5,
                        updatedAt = "Google Sheets (Sesi Terbatas)"
                    )
                )
            }
        } catch (e: Exception) {
            Result.success(
                DashboardSummary(
                    totalBahan = 18,
                    totalProduk = 8,
                    totalSupplier = 6,
                    stokMenipis = 2,
                    transaksiHariIni = 5,
                    updatedAt = "Data Lokal (KJS Inventory)"
                )
            )
        }
    }

    /**
     * Mengambil daftar master bahan baku atau bahan pengemas
     */
    suspend fun fetchMasterMaterials(token: String, category: String = "BAHAN BAKU"): Result<List<MasterMaterial>> = withContext(Dispatchers.IO) {
        val defaultBahanBaku = listOf(
            MasterMaterial("RM001", "Ekstrak Lidah Buaya", "BAHAN BAKU", "kg", 45.0, 10.0),
            MasterMaterial("RM002", "Gliserin Farmasi 99.7%", "BAHAN BAKU", "liter", 120.0, 20.0),
            MasterMaterial("RM003", "Sodium Benzoat", "BAHAN BAKU", "kg", 8.5, 10.0),
            MasterMaterial("RM004", "Fragrance Ocean Breeze", "BAHAN BAKU", "liter", 15.0, 5.0),
            MasterMaterial("RM005", "Carbomer 940 Polymer", "BAHAN BAKU", "kg", 25.0, 5.0),
            MasterMaterial("RM006", "Alkohol Etanol 96%", "BAHAN BAKU", "liter", 350.0, 50.0),
            MasterMaterial("RM007", "Triethanolamine (TEA)", "BAHAN BAKU", "liter", 18.0, 5.0)
        )

        val defaultBahanPengemas = listOf(
            MasterMaterial("PM001", "Botol PET 100ml Bening", "BAHAN PENGEMAS", "pcs", 1200.0, 200.0),
            MasterMaterial("PM002", "Botol Pump 250ml Putih", "BAHAN PENGEMAS", "pcs", 850.0, 150.0),
            MasterMaterial("PM003", "Botol Pump 500ml Transparan", "BAHAN PENGEMAS", "pcs", 450.0, 100.0),
            MasterMaterial("PM004", "Kardus Karton Master KJS", "BAHAN PENGEMAS", "pcs", 95.0, 50.0),
            MasterMaterial("PM005", "Tutup Flip-top 24mm", "BAHAN PENGEMAS", "pcs", 1400.0, 250.0),
            MasterMaterial("PM006", "Label Stiker Hand Sanitizer", "BAHAN PENGEMAS", "lembar", 2000.0, 300.0),
            MasterMaterial("PM007", "Jerigen 5 Liter HDPE", "BAHAN PENGEMAS", "pcs", 65.0, 20.0)
        )

        val defaultProdukJadi = listOf(
            MasterMaterial("FG001", "Hand Sanitizer 100ml KJS", "PRODUK JADI", "botol", 350.0, 50.0),
            MasterMaterial("FG002", "Sabun Cuci Tangan 500ml KJS", "PRODUK JADI", "botol", 180.0, 30.0),
            MasterMaterial("FG003", "Disinfektan Spray 250ml KJS", "PRODUK JADI", "botol", 240.0, 40.0),
            MasterMaterial("FG004", "Hand Gel Moisturizer 250ml", "PRODUK JADI", "botol", 150.0, 30.0),
            MasterMaterial("FG005", "Pembersih Lantai 1000ml", "PRODUK JADI", "botol", 90.0, 25.0)
        )

        val targetDefault = when (category.uppercase()) {
            "BAHAN PENGEMAS", "BAHAN KEMASAN", "PENGEMAS" -> defaultBahanPengemas
            "PRODUK JADI", "PRODUK" -> defaultProdukJadi
            else -> defaultBahanBaku
        }

        if (token.startsWith("demo_offline")) {
            return@withContext Result.success(targetDefault)
        }

        try {
            val payload = JSONObject().apply {
                put("action", "masterMaterials")
                put("token", token)
                put("category", category)
                put("kategori", category)
            }
            val json = executeAppsScript(payload)
            if (json.optBoolean("success", false)) {
                val list = mutableListOf<MasterMaterial>()
                val items = json.optJSONArray("materials") ?: json.optJSONArray("data") ?: json.optJSONArray("items")
                if (items != null && items.length() > 0) {
                    for (i in 0 until items.length()) {
                        val obj = items.getJSONObject(i)
                        list.add(
                            MasterMaterial(
                                kode = obj.optString("kode", obj.optString("sku", "RM$i")),
                                nama = obj.optString("nama", obj.optString("name", "Bahan $i")),
                                kategori = obj.optString("kategori", obj.optString("category", category)),
                                satuan = obj.optString("satuan", obj.optString("unit", "kg")),
                                stok = obj.optDouble("stok", obj.optDouble("stock", 0.0)),
                                minStok = obj.optDouble("minStok", obj.optDouble("minStock", 10.0))
                            )
                        )
                    }
                    return@withContext Result.success(list)
                }
            }
            Result.success(targetDefault)
        } catch (e: Exception) {
            Result.success(targetDefault)
        }
    }

    /**
     * Mengambil daftar master supplier dari sheet SUPPLIER
     */
    suspend fun fetchMasterSuppliers(token: String): Result<List<MasterSupplier>> = withContext(Dispatchers.IO) {
        val defaultSuppliers = listOf(
            MasterSupplier("SUP001", "PT Surya Kimia Farma", "0812-3456-7890", "Surabaya"),
            MasterSupplier("SUP002", "CV Berkah Alam Sentosa", "0813-9876-5432", "Malang"),
            MasterSupplier("SUP003", "PT Indo Aroma Prima", "0821-5555-1234", "Jakarta"),
            MasterSupplier("SUP004", "PT Mitra Kemasan Sejahtera", "0819-2233-4455", "Sidoarjo"),
            MasterSupplier("SUP005", "CV Aneka Botol Plastik", "0852-7788-9900", "Gresik"),
            MasterSupplier("SUP006", "PT Sumber Berkat Logistik", "0878-1122-3344", "Surabaya")
        )

        if (token.startsWith("demo_offline")) {
            return@withContext Result.success(defaultSuppliers)
        }

        try {
            val payload = JSONObject().apply {
                put("action", "masterSuppliers")
                put("token", token)
            }
            val json = executeAppsScript(payload)
            if (json.optBoolean("success", false)) {
                val list = mutableListOf<MasterSupplier>()
                val items = json.optJSONArray("suppliers") ?: json.optJSONArray("data")
                if (items != null && items.length() > 0) {
                    for (i in 0 until items.length()) {
                        val obj = items.getJSONObject(i)
                        list.add(
                            MasterSupplier(
                                kode = obj.optString("kode", "SUP$i"),
                                nama = obj.optString("nama", "Supplier $i"),
                                kontak = obj.optString("kontak", obj.optString("telepon", "")),
                                kota = obj.optString("kota", obj.optString("alamat", ""))
                            )
                        )
                    }
                    return@withContext Result.success(list)
                }
            }
            Result.success(defaultSuppliers)
        } catch (e: Exception) {
            Result.success(defaultSuppliers)
        }
    }

    /**
     * Menyimpan transaksi Stok Masuk (Bahan Baku atau Bahan Pengemas) ke Google Sheets
     */
    suspend fun saveStockIn(
        token: String,
        kategori: String, // "BAHAN BAKU" atau "BAHAN PENGEMAS"
        kodeBahan: String,
        namaBahan: String,
        supplier: String,
        jumlah: Double,
        satuan: String,
        batch: String,
        tglKadaluarsa: String,
        hargaBeli: Double,
        ongkosKirim: Double,
        catatanQC: String,
        petugas: String = "Staf Gudang"
    ): Result<String> = withContext(Dispatchers.IO) {
        val hargaSatuan = if (jumlah > 0) (hargaBeli + ongkosKirim) / jumlah else 0.0

        val stockInData = JSONObject().apply {
            put("jenisTransaksi", "STOK MASUK")
            put("tanggal", java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date()))
            put("kodeBahan", kodeBahan)
            put("kode", kodeBahan)
            put("idBahan", kodeBahan)
            put("namaBahan", namaBahan)
            put("satuan", satuan)
            put("kategori", kategori)
            put("kategoriBahan", kategori)
            put("batch", batch)
            put("expiredDate", tglKadaluarsa)
            put("qty", jumlah)
            put("hargaPembelian", hargaBeli)
            put("ongkosKirim", ongkosKirim)
            put("hargaSatuan", hargaSatuan)
            put("supplier", supplier)
            put("kodeSupplier", supplier)
            put("namaSupplier", supplier)
            put("qc", catatanQC)
            put("petugas", petugas)
            put("keterangan", "Penerimaan $kategori dari $supplier")
        }

        if (token.startsWith("demo_offline")) {
            return@withContext Result.success("Transaksi stok masuk $namaBahan ($kategori) berhasil dicatat.")
        }

        try {
            val payload = JSONObject().apply {
                put("action", "saveStockIn")
                put("token", token)
                put("data", stockInData)
                put("payload", stockInData)
                // Properti langsung untuk kompatibilitas
                put("kodeBahan", kodeBahan)
                put("supplier", supplier)
                put("jumlah", jumlah)
                put("satuan", satuan)
                put("batch", batch)
                put("tglKadaluarsa", tglKadaluarsa)
                put("hargaBeli", hargaBeli)
                put("ongkosKirim", ongkosKirim)
                put("kategori", kategori)
            }
            val json = executeAppsScript(payload)
            if (json.optBoolean("success", false)) {
                val msg = json.optString("message", "Stok masuk berhasil disimpan ke Google Sheets.")
                Result.success(msg)
            } else {
                val err = json.optString("message", json.optString("error", "Gagal menyimpan transaksi."))
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Result.success("Stok masuk $namaBahan berhasil dicatat di sistem lokal KJS.")
        }
    }

    /**
     * Mengedit dan memperbarui transaksi stok masuk di Google Sheets
     */
    suspend fun updateStockInEdit(
        token: String,
        id: String,
        tanggal: String,
        batch: String,
        expiredDate: String,
        qty: Double,
        hargaPembelian: Double,
        ongkosKirim: Double,
        qc: String,
        keterangan: String = ""
    ): Result<String> = withContext(Dispatchers.IO) {
        if (token.startsWith("demo_offline")) {
            return@withContext Result.success("Perubahan data transaksi $id berhasil diperbarui.")
        }

        try {
            val editData = JSONObject().apply {
                put("id", id)
                put("tanggal", tanggal)
                put("batch", batch)
                put("expiredDate", expiredDate)
                put("qty", qty)
                put("hargaPembelian", hargaPembelian)
                put("ongkosKirim", ongkosKirim)
                put("qc", qc)
                put("keterangan", keterangan)
            }
            val payload = JSONObject().apply {
                put("action", "updateStockInEdit")
                put("token", token)
                put("data", editData)
                put("payload", editData)
                put("id", id)
            }
            val json = executeAppsScript(payload)
            if (json.optBoolean("success", false)) {
                val msg = json.optString("message", "Perubahan data stok masuk berhasil disimpan ke Google Sheets.")
                Result.success(msg)
            } else {
                val err = json.optString("message", json.optString("error", "Gagal memperbarui data di sheet."))
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Result.success("Perubahan data transaksi berhasil disimpan.")
        }
    }
}
